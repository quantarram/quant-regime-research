"""
Pairwise CPE Engine — Parallelised, Bullish & Bearish (Clean Universe v2 + Economic Prior)
=============================================================================================
Excluded from Y (predicted):
  - Leveraged/inverse ETFs : SSO, SDS, TQQQ, TMF, TBT, TBF, UVXY, SVXY, VIXY, VIXM, VXX
  - Managed currencies     : THBUSD=X, CNYUSD=X, KRWUSD=X

Excluded from X (predictor):
  - Managed currencies     : THBUSD=X, CNYUSD=X, KRWUSD=X

ECONOMIC PRIOR (new):
  In addition to the exclusions above, every (Y, X) pair is now also
  required to clear economic_prior.is_admissible(X, Y) before any CPE is
  computed for it. This is the direct response to the Portfolio Tilt
  paper's central finding (Sections 11-14): raw CPE, shrinkage, sample-
  size filtering, and episode-independence filtering all failed to
  separate spurious-but-recurring relationships (silver -> dogecoin,
  GLD -> CORN) from genuine ones (volatility -> equities), because all
  four are computed from price history alone. The economic prior is a
  pre-specified, data-blind restriction on which (X, Y) pairs are even
  candidates, applied BEFORE the screen runs rather than filtered after.
  See economic_prior.py for the full taxonomy and channel list.

  This is implemented by restricting the per-Y predictor list before the
  parallel pool starts (computed once, not checked per-inner-loop-
  iteration), so the engine's hot path and performance characteristics
  are otherwise unchanged from the original.

Usage:
    export N_WORKERS=15
    export MIN_N=100
    export CPE_THRESH=0.80
    export MIN_LIFT=1.5
    python cpe_engine_parallel.py
"""

import pandas as pd
import numpy as np
import pyarrow.parquet as pq
from multiprocessing import Pool, cpu_count
from datetime import datetime
import warnings, os, time, glob
warnings.filterwarnings("ignore")

import os as _os_for_prior_switch
if _os_for_prior_switch.environ.get("USE_PRIOR_BYPASS") == "1":
    print("  *** USE_PRIOR_BYPASS=1: economic prior DISABLED, running unrestricted (A/B comparison arm) ***")
    from economic_prior_BYPASS import is_admissible, admissible_predictors_for
else:
    from economic_prior import is_admissible, admissible_predictors_for

# ── CONFIG ────────────────────────────────────────────────────────────────────
TAU_PAST    = [1, 5, 10, 21, 63, 126, 252, 300]
TAU_FUTURE  = [1, 5, 10, 21, 63, 126, 252, 300]
Q_GRID      = [0.50, 0.60, 0.70, 0.75, 0.80, 0.90, 0.95, 0.99]

N_WORKERS   = int(os.environ.get("N_WORKERS", max(1, cpu_count() - 1)))
CPE_THRESH  = float(os.environ.get("CPE_THRESH", 0.80))
MIN_SAMPLE  = int(os.environ.get("MIN_N", 100))
MIN_LIFT    = float(os.environ.get("MIN_LIFT", 1.5))

# Literature-review confidence floor for the economic prior. One of
# "weak" (default; accept any admissible channel, same as pre-review
# behaviour), "caveat", "standard", or "high" (only the out-of-sample-
# validated vol->equity channel and similarly strong entries). See
# economic_prior.py's CONFIDENCE_OVERRIDES and literature_review_tier2.md
# for what each tier means and why specific channels were placed there.
MIN_CONFIDENCE = os.environ.get("MIN_CONFIDENCE", "weak")

# Hard minimum training-period (<=2024-12-31) observation count for a
# ticker to be eligible as a PREDICTOR at all. This is a different check
# from MIN_N/min_n above: MIN_N counts how many times the CONDITIONING
# EVENT fired (e.g. "X crossed its 95th percentile threshold 122 times"),
# which a short-history ticker can clear easily if its whole brief life
# happens to be volatile. MIN_TRAIN_OBS instead checks the ticker's own
# total calendar history -- how many days of data even exist to estimate
# a threshold from in the first place.
#
# This directly targets a mechanism confirmed during this investigation:
# the existing h(Pi) down-weight (compute_h_for_joint_row in
# backtest_engine.py) discounts short-history predictors' CONVICTION/
# SIZING, but does not stop them from firing at all -- a discounted
# signal still fires on every day its threshold is crossed. In the
# backtest run that motivated this filter, IBIT/FBTC/BITB (245 training
# observations each, vs. a 756-observation full-trust point and a clean
# 5.6x gap to the next-shortest ticker in the universe at 1,387) were
# only 10 of 1,094 surviving joint configs by count, yet drove BTC/ETH
# tilt signals on 142 of 250 evaluation days -- removing crypto from the
# tradeable book entirely collapsed the static-tilt strategy's
# randomisation-test percentile from "marginally less random" (26%) to
# "actively worse than random" (79.8%), with the underlying no-tilt
# benchmark unchanged -- meaning the entire apparent crypto "signal" was
# concentrated in these three short-history tickers' down-weighted-but-
# still-firing configurations.
#
# Default of 500 sits in the large, clean gap between the three
# short-history tickers (245 obs) and the next-shortest ticker in the
# full 161-instrument universe (1,387 obs) -- any value in that gap
# produces an identical exclusion set, so this default is not a
# sensitive tuning choice.
MIN_TRAIN_OBS = int(os.environ.get("MIN_TRAIN_OBS", 500))

# ── EXCLUSIONS ────────────────────────────────────────────────────────────────
RATE_INDEX_TICKERS = {
    "^VIX","^VXN","^OVX","^GVZ","^EVZ","^VVIX","^SKEW",
    "^TNX","^TYX","^FVX","^IRX"
}

EXCLUDE_FROM_Y = {
    # Leveraged/inverse ETFs — mechanically implied signals
    "SSO","SDS","TQQQ",
    "TMF","TBT","TBF",
    "UVXY","SVXY","VIXY","VIXM","VXX",
    # Managed currencies — poor data quality / spurious signals
    "THBUSD=X","CNYUSD=X","KRWUSD=X",
}

EXCLUDE_FROM_X = {
    # Managed currencies — poor data quality / spurious signals
    "THBUSD=X","CNYUSD=X","KRWUSD=X",
}

TMP_DIR = "cpe_tmp_chunks"

# ── WORKER GLOBALS ────────────────────────────────────────────────────────────
_increments        = None
_future_inc        = None
_thresholds        = None
_predictor_tickers = None
_config            = None

def _init_worker(increments, future_inc, thresholds, predictor_tickers, config):
    global _increments, _future_inc, _thresholds, _predictor_tickers, _config
    _increments        = increments
    _future_inc        = future_inc
    _thresholds        = thresholds
    _predictor_tickers = predictor_tickers
    _config            = config


def _compute_cpe_for_y(args):
    y, chunk_id = args
    results = []

    cpe_thresh = _config["cpe_thresh"]
    min_n      = _config["min_n"]
    min_lift   = _config["min_lift"]
    tau_past_list   = _config["tau_past"]
    tau_future_list = _config["tau_future"]
    q_grid     = _config["q_grid"]
    min_confidence  = _config.get("min_confidence", "weak")

    # Economic prior: restrict candidate predictors for this target Y to
    # the pre-specified admissible set, computed once per task rather
    # than checked on every inner-loop iteration.
    y_predictors = [x for x in _predictor_tickers if is_admissible(x, y, min_confidence)]
    if not y_predictors:
        return 0

    for tau_f in tau_future_list:
        fy = _future_inc[tau_f][y]

        for tau_p in tau_past_list:
            px_all = _increments[tau_p]

            common_idx = fy.dropna().index.intersection(
                px_all.dropna(how="all").index
            )
            if len(common_idx) < min_n:
                continue

            fy_vals    = fy.loc[common_idx].values
            px_aligned = px_all.loc[common_idx]

            for q_y in q_grid:
                thresh_y_up = _thresholds[(tau_f, q_y)].get(y, np.nan)
                thresh_y_dn = _thresholds[(tau_f, round(1 - q_y, 10))].get(y, np.nan)

                if np.isnan(thresh_y_up) or np.isnan(thresh_y_dn):
                    continue

                uncond = 1.0 - q_y

                event_bull = fy_vals > thresh_y_up
                event_bear = fy_vals < thresh_y_dn

                for x in y_predictors:
                    px_vals    = px_aligned[x].values
                    valid_mask = ~np.isnan(px_vals)
                    if valid_mask.sum() < min_n:
                        continue

                    for q_x in q_grid:
                        thresh_x_up = _thresholds[(tau_p, q_x)].get(x, np.nan)
                        thresh_x_dn = _thresholds[(tau_p, round(1 - q_x, 10))].get(x, np.nan)

                        if np.isnan(thresh_x_up) or np.isnan(thresh_x_dn):
                            continue

                        # ── BULLISH ───────────────────────────────────────
                        cond_bull = valid_mask & (px_vals > thresh_x_up)
                        n_bull    = cond_bull.sum()
                        if n_bull >= min_n:
                            cpe_bull  = event_bull[cond_bull].mean()
                            lift_bull = cpe_bull / uncond if uncond > 0 else np.nan
                            if cpe_bull >= cpe_thresh and lift_bull >= min_lift:
                                results.append((
                                    y, x, tau_p, tau_f, q_x, q_y,
                                    round(float(cpe_bull), 4),
                                    round(float(uncond), 4),
                                    round(float(lift_bull), 4),
                                    int(n_bull), len(common_idx),
                                    "bullish"
                                ))

                        # ── BEARISH ───────────────────────────────────────
                        cond_bear = valid_mask & (px_vals < thresh_x_dn)
                        n_bear    = cond_bear.sum()
                        if n_bear >= min_n:
                            cpe_bear  = event_bear[cond_bear].mean()
                            lift_bear = cpe_bear / uncond if uncond > 0 else np.nan
                            if cpe_bear >= cpe_thresh and lift_bear >= min_lift:
                                results.append((
                                    y, x, tau_p, tau_f, q_x, q_y,
                                    round(float(cpe_bear), 4),
                                    round(float(uncond), 4),
                                    round(float(lift_bear), 4),
                                    int(n_bear), len(common_idx),
                                    "bearish"
                                ))

    if results:
        os.makedirs(TMP_DIR, exist_ok=True)
        cols = ["Y","X","tau_past","tau_future","q_X","q_Y",
                "CPE","uncond_prob","lift","n_condition","n_total","direction"]
        df_chunk = pd.DataFrame(results, columns=cols)
        chunk_path = os.path.join(TMP_DIR, f"chunk_{chunk_id:05d}.parquet")
        df_chunk.to_parquet(chunk_path, engine="pyarrow",
                            compression="snappy", index=False)
        return len(results)
    return 0


# ── MAIN ──────────────────────────────────────────────────────────────────────
def main():
    print(f"\n{'='*65}")
    print(f"  CPE ENGINE (CLEAN UNIVERSE v2 + ECONOMIC PRIOR)  |  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Workers : {N_WORKERS}")
    print(f"{'='*65}")

    prices = pd.read_parquet("multiasset_prices.parquet")

    all_tickers   = list(prices.columns)
    price_tickers = [t for t in all_tickers if t not in RATE_INDEX_TICKERS]
    rate_tickers  = [t for t in all_tickers if t in RATE_INDEX_TICKERS]

    predicted_tickers = [t for t in price_tickers if t not in EXCLUDE_FROM_Y]
    predictor_tickers = [t for t in all_tickers   if t not in EXCLUDE_FROM_X]

    # Hard training-history filter, applied ONLY to the predictor (X)
    # side. A short-history ticker can still legitimately be a TARGET
    # (we may well want to know whether BTC-USD itself is predictable),
    # the problem this filter addresses is specifically conditioning on
    # a thinly-historied instrument's threshold crossings, which is what
    # let IBIT/FBTC/BITB dominate the crypto sleeve's trading activity
    # despite being discounted, not excluded, by the existing h(Pi)
    # weight. See MIN_TRAIN_OBS definition above for the full rationale.
    TRAIN_CUTOFF_FOR_HISTORY_CHECK = pd.Timestamp("2024-12-31")
    train_obs_counts = {}
    for t in predictor_tickers:
        s = prices[t].dropna()
        train_obs_counts[t] = int((s.index <= TRAIN_CUTOFF_FOR_HISTORY_CHECK).sum())

    short_history_excluded = sorted(
        t for t, n in train_obs_counts.items() if n < MIN_TRAIN_OBS
    )
    predictor_tickers = [t for t in predictor_tickers if train_obs_counts[t] >= MIN_TRAIN_OBS]

    print(f"  All tickers          : {len(all_tickers)}")
    print(f"  Excluded from Y      : {sorted(EXCLUDE_FROM_Y)}")
    print(f"  Excluded from X      : {sorted(EXCLUDE_FROM_X)}")
    print(f"  Min train obs (X)    : {MIN_TRAIN_OBS}  "
          f"(hard predictor-eligibility floor, see MIN_TRAIN_OBS comment above)")
    if short_history_excluded:
        print(f"  Predictors excluded for insufficient training history "
              f"({len(short_history_excluded)}): {short_history_excluded}")
        for t in short_history_excluded:
            print(f"      {t:<10} {train_obs_counts[t]} training observations "
                  f"(< {MIN_TRAIN_OBS} required)")
    else:
        print(f"  No predictors excluded for insufficient training history "
              f"(all clear {MIN_TRAIN_OBS} observations)")
    print(f"  Predicted Y          : {len(predicted_tickers)}")
    print(f"  Predictors X         : {len(predictor_tickers)}")
    print(f"  Min confidence       : {MIN_CONFIDENCE}  "
          f"(see economic_prior.py CONFIDENCE_OVERRIDES / literature_review_tier2.md)")

    # Economic-prior coverage diagnostic — printed before any computation
    # so a thin or pathological prior is caught immediately, not after a
    # multi-minute run.
    n_admissible_pairs = sum(
        1 for y in predicted_tickers for x in predictor_tickers
        if is_admissible(x, y, MIN_CONFIDENCE)
    )
    n_total_pairs = len(predicted_tickers) * len(predictor_tickers)
    zero_cov = [y for y in predicted_tickers
                if not admissible_predictors_for(y, predictor_tickers, MIN_CONFIDENCE)]
    print(f"  Economic prior       : {n_admissible_pairs:,} / {n_total_pairs:,} "
          f"(X,Y) pairs admissible ({100*n_admissible_pairs/n_total_pairs:.2f}%)")
    if zero_cov:
        print(f"  Targets with ZERO admissible predictors ({len(zero_cov)}): {sorted(zero_cov)}")

    print(f"\n  Pre-computing increments...")
    all_taus = sorted(set(TAU_PAST + TAU_FUTURE))
    increments = {}
    for tau in all_taus:
        inc = pd.DataFrame(index=prices.index)
        for t in price_tickers:
            s = prices[t]
            inc[t] = np.log(s / s.shift(tau))
        for t in rate_tickers:
            s = prices[t]
            inc[t] = s - s.shift(tau)
        increments[tau] = inc
        print(f"    tau={tau:>3}  shape={inc.shape}")

    print(f"\n  Pre-computing forward increments for Y...")
    future_inc = {}
    for tau_f in TAU_FUTURE:
        fi = increments[tau_f][predicted_tickers].shift(-tau_f)
        future_inc[tau_f] = fi
        print(f"    tau_f={tau_f:>3}  non-null rows: {fi.dropna(how='all').shape[0]}")

    full_q_grid = sorted(set(Q_GRID + [round(1 - q, 10) for q in Q_GRID]))
    print(f"\n  Pre-computing quantile thresholds...")
    thresholds = {}
    for tau in all_taus:
        for q in full_q_grid:
            thresholds[(tau, q)] = increments[tau].quantile(
                q, numeric_only=True).to_dict()
    print(f"  Done. {len(thresholds)} (tau, q) threshold dicts.")

    config = dict(
        cpe_thresh=CPE_THRESH, min_n=MIN_SAMPLE, min_lift=MIN_LIFT,
        tau_past=TAU_PAST, tau_future=TAU_FUTURE, q_grid=Q_GRID,
        min_confidence=MIN_CONFIDENCE,
    )

    if os.path.exists(TMP_DIR):
        for f in glob.glob(os.path.join(TMP_DIR, "*.parquet")):
            os.remove(f)

    tasks = [(y, i) for i, y in enumerate(predicted_tickers)]

    total_combos = (n_admissible_pairs *
                    len(TAU_PAST) * len(TAU_FUTURE) * len(Q_GRID) ** 2 * 2)
    unrestricted_combos = (len(predicted_tickers) * len(predictor_tickers) *
                    len(TAU_PAST) * len(TAU_FUTURE) * len(Q_GRID) ** 2 * 2)
    print(f"\n  Total combinations   : {total_combos:,}  "
          f"(prior-restricted; unrestricted would be {unrestricted_combos:,})")
    print(f"  Tasks (one per Y)  : {len(tasks)}")
    print(f"  Filter             : CPE >= {CPE_THRESH} AND lift >= {MIN_LIFT} AND n >= {MIN_SAMPLE}")
    print(f"\n  Running...\n")

    t0 = time.time()
    n_kept_total = 0

    initargs = (increments, future_inc, thresholds, predictor_tickers, config)

    with Pool(processes=N_WORKERS, initializer=_init_worker, initargs=initargs) as pool:
        for i, n_kept in enumerate(pool.imap_unordered(_compute_cpe_for_y, tasks)):
            n_kept_total += n_kept
            elapsed = time.time() - t0
            rate    = (i + 1) / elapsed if elapsed > 0 else 0
            eta     = (len(tasks) - i - 1) / rate if rate > 0 else 0
            print(f"  [{i+1:>3}/{len(tasks)}]  kept: {n_kept_total:>8,}  "
                  f"rate: {rate:.1f} Y/s  ETA: {eta/60:.1f} min", end="\r")

    print(f"\n\n  All workers done. Elapsed: {(time.time()-t0)/60:.1f} min")

    print(f"\n  Concatenating chunk files...")
    chunk_files = sorted(glob.glob(os.path.join(TMP_DIR, "*.parquet")))
    print(f"  Found {len(chunk_files)} chunk files")

    if chunk_files:
        dfs    = [pd.read_parquet(f) for f in chunk_files]
        df_all = pd.concat(dfs, ignore_index=True)
        df_all = df_all.sort_values(
            ["direction","Y","tau_future","tau_past","q_Y","q_X","CPE"],
            ascending=[True,True,True,True,True,True,False]
        ).reset_index(drop=True)

        out_path = "cpe_results.parquet"
        df_all.to_parquet(out_path, engine="pyarrow",
                          compression="snappy", index=False)

        elapsed_total = time.time() - t0
        print(f"\n{'='*65}")
        print(f"  COMPLETE")
        print(f"  Total rows kept   : {len(df_all):,}")
        print(f"  Total elapsed     : {elapsed_total/60:.1f} min")
        print(f"  Saved → {out_path}  ({os.path.getsize(out_path)/1e6:.1f} MB)")
        print(f"\n  Direction breakdown:")
        print(df_all.groupby("direction")["CPE"].describe().round(3).to_string())
        print(f"\n  Top CPE bullish:")
        print(df_all[df_all["direction"]=="bullish"].nlargest(10,"CPE")[
            ["Y","X","tau_past","tau_future","q_X","q_Y","CPE","uncond_prob","lift","n_condition"]
        ].to_string(index=False))
        print(f"\n  Top CPE bearish:")
        print(df_all[df_all["direction"]=="bearish"].nlargest(10,"CPE")[
            ["Y","X","tau_past","tau_future","q_X","q_Y","CPE","uncond_prob","lift","n_condition"]
        ].to_string(index=False))
        print(f"{'='*65}\n")

        for f in chunk_files:
            os.remove(f)
        os.rmdir(TMP_DIR)
    else:
        print("  No results passed the filter thresholds.")


if __name__ == "__main__":
    main()
